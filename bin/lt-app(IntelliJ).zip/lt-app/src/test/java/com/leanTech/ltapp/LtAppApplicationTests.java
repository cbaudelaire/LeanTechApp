package com.leanTech.ltapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
