package com.leanTech.ltapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LtAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LtAppApplication.class, args);
	}

}
