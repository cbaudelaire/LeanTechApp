package com.leanTech.ltapp.model.service;

import com.leanTech.ltapp.model.entity.Person;

public interface IPersonService {

    public Person createPerson(Person person);

}
